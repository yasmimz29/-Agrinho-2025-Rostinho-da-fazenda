function setup() {
  createCanvas(400, 400);
}

let xJogador1 = 0;
let xJogador2 = 0;

function draw() {
  ativaJogo();
  desenhaJogadores();
  desenhaLinhaDeChegada();
  verificaVencedor();
}


function ativaJogo() {
  if (focused == true) {
    background("#4CAF50");
  } else {
    background("#8BC34A");
    text("Corrida de fazenda",20,60)
    text("Para iniciar esse", 50, 100);
    text("jogo é nessesá-", 30, 140);
    text("rio clicar na tela,", 30, 180);
    text("para mover os",30, 220);
    text("personagens",30, 260);
    text("as teclas A e S",40, 290);
  }
}

function desenhaJogadores() {
  textSize(40);
  text("🐮", xJogador1, 100);
  text("🐓", xJogador2, 300);
}

function desenhaLinhaDeChegada() {
  fill("#FFC107");
  rect(350, 0, 10, 400);
  fill("#F44336");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  if (xJogador1 > 350) {
    text("Jogador 1 venceu!", 50, 200);
    noLoop();
  }
  if (xJogador2 > 350) {
    text("Jogador 2 venceu!", 50, 200);
    noLoop();
  }
}

function keyReleased() {
  if (key == "a") {
    xJogador1 += random(20);
  }
  if (key == "s") {
    xJogador2 += random(20);
  }
}