function setup() {
  createCanvas(400, 400);
  
} 
//referencias:p5js
//p5js
  

let olhoX;
let olhoY;
function draw() {
 
    background('#89FF00'); //fundo
    fill("rgb(255,97,0)");
    circle(200, 200, 300); //rosto
    fill('#FFC107')
    circle(150, 150, 60); //olho esquerdo
    circle(250, 150, 60); //olho direito
    line(150, 300, 260, 300); //boca
    fill('#FF7700');
    triangle(200, 200, 200, 250, 150, 220); //nariz
    line(123, 125, 188, 113); //sombrancelha esquerda             
    line(220,115,280,103) //sombrancelha direita
    line(110, 78,116, 322);
    line(66, 130,75, 281);
    line(173, 50, 182, 348);
    line(227, 52, 244, 341);
    line(289,79, 279, 330);
    line(331,130,326,277);
    fill('#795548');
    rect(180, 2, 20, 50); 
  // circle(150,150,10); //pupila esquerda
    // circle(250,150,10); //pupila direita
     
  olhoX = map(mouseX,0,400,126,155);
  olhoY = map(mouseY,0,400,126,163); 
 
  circle(olhoX,olhoY,10); // nova pupila direita
  circle(olhoX+100,olhoY,10) ; // nova pupila esquerda
    
   text("Abóbora", 90, 50);
   text("Mecha o mause em", 17,70)
   text("sima do quadro", 17,81)
 
  if (mouseIsPressed) {
    console.log(mouseX, mouseY);
    
  }
}